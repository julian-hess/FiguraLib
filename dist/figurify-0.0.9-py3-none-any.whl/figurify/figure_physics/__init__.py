from figurify.figure_physics.dynamics import *
from figurify.figure_physics.energy import *
from figurify.figure_physics.forces import *
from figurify.figure_physics.gravity import *
from figurify.figure_physics.kinematics import *
from figurify.figure_physics.momentum import *

from figurify.figure_physics import dynamics
from figurify.figure_physics import energy
from figurify.figure_physics import forces
from figurify.figure_physics import gravity
from figurify.figure_physics import kinematics
from figurify.figure_physics import momentum