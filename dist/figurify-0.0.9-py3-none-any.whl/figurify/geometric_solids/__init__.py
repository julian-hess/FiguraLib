from figurify.geometric_solids.cone import *
from figurify.geometric_solids.cube import *
from figurify.geometric_solids.cuboid import *
from figurify.geometric_solids.cylinder import *
from figurify.geometric_solids.prism import *
from figurify.geometric_solids.pyramid import *
from figurify.geometric_solids.sphere import *
from figurify.geometric_solids.torus import *

from figurify.geometric_solids import cone
from figurify.geometric_solids import cube
from figurify.geometric_solids import cuboid
from figurify.geometric_solids import cylinder
from figurify.geometric_solids import prism
from figurify.geometric_solids import pyramid
from figurify.geometric_solids import sphere
from figurify.geometric_solids import torus